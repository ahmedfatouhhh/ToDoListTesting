import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestSuite {
    WebDriver driver;
    SoftAssert softAssert;

    @BeforeTest
    public void openBrowser() {
        driver = new ChromeDriver();
        softAssert = new SoftAssert();
        driver.get("file:///C:/Users/dell/Documents/todo_app.html");
    }

    @Test(priority = 1)
    public void testTitleDisplayed() {
        String expected = "Todo List";
        String actual = driver.findElement(By.xpath("/html/body/h1")).getText();
        softAssert.assertTrue(actual.contains(expected));
        softAssert.assertAll();
    }

    @Test(priority = 2)
    public void testAddTask() {
        WebElement taskInput = driver.findElement(By.id("new-task"));
        taskInput.clear();
        taskInput.sendKeys("Task 1");

        WebElement addButton = driver.findElement(By.xpath("/html/body/button"));
        addButton.click();

        String expected = "Task 1";
        String actual = driver.findElement(By.xpath("//*[@id='task-list']/li")).getText();
        softAssert.assertTrue(actual.contains(expected));
        softAssert.assertAll();
    }

    @Test(priority = 3)
    public void testCompleteAndDeleteTask() {
        WebElement completeButton = driver.findElement(By.xpath("//*[@id='task-list']/li/button[1]"));
        completeButton.click();

        WebElement deleteButton = driver.findElement(By.xpath("//*[@id='task-list']/li/button[2]"));
        deleteButton.click();

        int remainingTasks = driver.findElements(By.xpath("//*[@id='task-list']/li")).size();
        softAssert.assertEquals(remainingTasks, 0);
        softAssert.assertAll();
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit();
    }
}
